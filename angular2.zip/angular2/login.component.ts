import { Component } from '@angular/core';

@Component({
    selector: 'login',
    templateUrl: `./login.component.html`,
    //styleUrls:['./login.component.css']
})
export class LoginComponent{
    username: string;
    password: string;
    message: string;
    auth(){
        if(this.username == 'rahulk@12' && this.password == 'qwerty')
            this.message='Welcome '+this.username ;
        else
            this.message='Invalid';
   }
}
    
    