import {Injectable} from '@angular/core';
import { Product } from 'src/app/product';


/*
classes in which we write code in Angular 
for communicating with the sever are 
commonly referred to as service classes
*/
@Injectable()
export class ProductService{
    // as of now we will return dummy list of products
    //in a realtime scenario we will ,make an AJAX
    //call from here tothe server
    fetchListOfProducts() :Product[] {
        return[
        new Product(1,"nokia 6600",5000,99,"img_image.jpg.jpg"),
        new Product(2,"Sony Xperia",25000,99,"sonyimage.jpg"),
        new Product(3,"Samsung s10",35000,99,"samsungimage.jpg"),
        new Product(4,"iphone X",55000,99,"iphoneimage.jpg"),
        new Product(5,"MI NOTE 7",15000,99,"miimage.jpg")]
    }
}