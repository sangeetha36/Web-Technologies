import { Component } from '@angular/core';

@Component({
    selector: 'random-no',
    template: `
    <button (click)="get()">Generate</button>
    <h1 *ngIf="no>=0">Your lucky No is </h1>
    <h1>{{no}}</h1>`
})
export class RandomComponent{
    no : number;
    get() {
        this.no=Math.floor(Math.random()*100);
    }
    
    
}