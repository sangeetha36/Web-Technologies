import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { HelloComponent } from 'src/app/hello.component';
import { RandomComponent } from 'src/app/random.component';
import { LoginComponent } from 'src/app/login.component';
import { CalciComponent } from 'src/app/calci.component';
import { ProductList } from 'src/app/product.component';

@NgModule({
  declarations: [
    AppComponent,
    HelloComponent,
    RandomComponent,
    LoginComponent,
    CalciComponent,
    ProductList
  ],
  imports: [
    BrowserModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
