import { Component } from '@angular/core';

@Component({
    selector: 'calci',
    templateUrl: `./calci.component.html`
})
export class CalciComponent{
    result:number;
    a:number;
    b:number;
    add(){
        this.result=this.a+this.b;
   }
   sub(){
    this.result=this.a-this.b;
}

mul(){
    this.result=this.a*this.b;
}
div(){
    this.result=this.a/this.b;
}
}
    
    