import { Component } from '@angular/core';

@Component({
selector: 'productlist',
templateUrl: `./product.component.html`,
styleUrls:['./product.component.css']
})
export class ProductList{
    myVar:boolean=false;
    p_ar:Product[];
    display(){
        this.p_ar=[new Product(12000,'MOB100',200,'Xiaomi 5'),new Product(72000,'MOB102',20,'iPhone XR'),new Product(120000,'MOB105',15,'Oneplus 7 Pro')];
    }
}
export class Product{
    price: number;
    id: string;
    quantity: number;
    name: string;
    constructor(price:number,id:string,quantity:number,name:string)
    {
        this.id=id;
        this.quantity=quantity;
        this.name=name;
        this.price=price;
    }
}